<html>
<head>
        <title>Management system</title>
    <style>
    #menu
    {
        width:75%;
        text-align:center;
        background-color:lightgreen;
        color:white;
        font-size:20px;
        
    }
    #menu a
    {
        text-decoration:none;
        color:Red;

    }
    </style>
</head>
    <body>
        <h1>welcome</h1>
        <table border="1" width="80%" align="center" height="20%">
            <tr>
                <td width="10%" bgcolor="green"><img src="image\download (9).jpg" alt="image" width="150px" height="150"></td>
          <td bgcolor="skyblue" style="font-size:25px;text-align:center; text-shadow:3px 3px 3px white;">Student Management System</td>
        </tr>
         
                
        </table  >
        
        
        <table border="1" width="80%" align="center" height="40%">
            <tr>
            <td>
                <img src="image\download (9).jpg" alt="image" width="100%" height="500px">
            </td>
        </tr>
        </table>
        <table border="1" width="80%" id="menu" align="center" height="8%">
            <tr>
            <td><a href="index.php">Home</a>             
            </td>
            <td><a href="reg.php">Registration</a>             
            </td>
            <td><a href="view.php">student Record</a>             
            </td>
        </tr>
        </table>
        <table border="1" width="80%" align="center" height="8%">
            <tr>
            <td bgcolor="skyblue" style="font-size:25px;background-color:#333333;text-align:center;">Student Management System</td>
        </tr>
        </table>

    </body>
</html>