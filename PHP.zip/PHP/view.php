
<html>
    <head>
        <title>registration </title>
        <style>
             #menu
    {
        width:75%;
        text-align:center;
        background-color:lightgreen;
        color:white;
        font-size:20px;
        
    }
    #menu a
    {
        text-decoration:none;
        color:Red;

    }
        </style>
    </head>
    <body>
    <table border="1" width="80%" align="center" height="20%">
            <tr>
                <td width="10%" bgcolor="green"><img src="image\download (9).jpg" alt="image" width="150px" height="150"></td>
          <td bgcolor="skyblue" style="font-size:25px;text-align:center; text-shadow:3px 3px 3px white;">Student Management System</td>
        </tr>
         
                
        </table  >
        <table border="1" width="80%" id="menu" align="center" height="8%">
            <tr>
            <td><a href="index.php">Home</a>             
            </td>
            <td><a href="reg.php">Registration</a>             
            </td>
            <td><a href="view.php">student Record</a>             
            </td>
        </tr>
        </table>
        <table border="1" width="80%" align="center" height="8%">
<tr style="background-color:#003366;color:white;">
    <td> name   
    </td>
    <td> cname   
    </td>
    <td> email   
    </td>
</tr>
<?php
include("connnection.php");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM reg";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        
        while($row = $result->fetch_assoc())
{
    ?>
    <tr>
            <td><?php echo $row['name'];   ?>          
            </td>
            <td><?php echo $row['cname'];   ?>             
            </td>
            <td><?php echo $row['email'];   ?>             
            </td>
    </tr>
    <?php

}
    }
    else {
        echo "<tr><td colspan='5'>No students found</td></tr>";
    }
    $conn->close();
?>
        </table>
        <table border="1" width="80%" align="center" height="8%">
            <tr>
            <td bgcolor="skyblue" style="font-size:25px;background-color:#333333;text-align:center;">Student Management System</td>
        </tr>
        </table>
        
    </body>
</html>